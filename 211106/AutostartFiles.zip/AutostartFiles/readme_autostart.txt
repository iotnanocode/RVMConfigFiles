AutoStart de servicios al reiniciar
Los archivos init de tipo desktop deben de ir en el directorio /etc/xdg/autostart/